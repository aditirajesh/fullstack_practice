# server.py
import socket

def start_server():
    # Define the server address and port
    server_address = ('localhost', 12346)

    # Create a TCP/IP socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
        # Bind the socket to the address
        server_socket.bind(server_address)
        
        # Listen for incoming connections
        server_socket.listen(1)
        print("Server is listening on", server_address)

        # Wait for a connection
        while True:
            print("Waiting for a connection...")
            connection, client_address = server_socket.accept()
            with connection:
                print("Connected to", client_address)
                
                while True:
                    # Receive data from the client
                    data = connection.recv(1024)
                    if not data:
                        # Connection closed by client
                        print("Client disconnected")
                        break

                    # Decode the message
                    message = data.decode()
                    print("Received:", message)

                    # Check if the client wants to exit
                    if message.lower() == "exit":
                        print("Client requested to close the connection.")
                        break
                    
                    # Echo the message back to the client
                    connection.sendall(data)
                    print("Echoed back:", message)

# Run the server
if __name__ == "__main__":
    start_server()
