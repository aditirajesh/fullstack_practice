import urllib.request

url = 'https://github.com/aditirajesh/fullstack_practice/blob/main/Cloud_lab.zip'  # Replace with your raw link
output_path = 'downloaded_file.zip'  # Name for the file to save

urllib.request.urlretrieve(url, output_path)

print("Download complete!")