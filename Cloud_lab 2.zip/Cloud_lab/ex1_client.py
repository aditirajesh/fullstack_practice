# client.py
import socket

def start_client():
    # Define the server address and port
    server_address = ('localhost', 12346)

    # Create a TCP/IP socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
        # Connect to the server
        client_socket.connect(server_address)
        
        print("Connected to server. Type 'exit' to end the connection.")
        
        while True:
            # Get user input
            message = input("Enter message to send: ")
            
            # Send the message to the server
            client_socket.sendall(message.encode())
            
            # Check if the user wants to exit
            if message.lower() == "exit":
                print("Closing connection.")
                break
            
            # Receive the echoed message from the server
            data = client_socket.recv(1024)
            print("Received echo:", data.decode())

# Run the client
if __name__ == "__main__":
    start_client()
