import socket 

def add(a,b):
    return a+b

def subtract(a,b):
    return a-b 

def process_request(req):
    request = req.split()
    if len(request) != 3:
        return 'Invalid request sent'
    
    command, a, b = request 

    try:
        a,b = int(a), int(b)

    except ValueError:
        return 'arguments must be integers'
    
    if command == 'add':
        result = add(a,b)

    elif command == 'subtract':
        result = subtract(a,b)

    else:
        return 'invalid command'
    
    return str(result) 

server_address = ('localhost',5011)
server_socket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
server_socket.bind(server_address)
server_socket.listen()

while True:
    client_socket,client_address = server_socket.accept()
    request = client_socket.recv(1024).decode()
    print(f'{request} - message from client')
    result = process_request(request)

    client_socket.send(result.encode())
    print('result sent to client...')
    client_socket.close()