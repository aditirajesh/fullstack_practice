import socket 

server_address = ('localhost',5011)
client_socket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
client_socket.connect(server_address)

req = input('Enter request to send to server')
client_socket.send(req.encode())
print('Request sent to server')

result = client_socket.recv(1024).decode()
print('result is: ',result)

client_socket.close()