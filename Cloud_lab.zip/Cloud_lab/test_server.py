import socket 
import threading 

clients = []

def handle_clients(client_socket,address):
    print(f'{address} has connected to the server')
    clients.append(client_socket)

    while True:

        try: 
            data = client_socket.recv(1024).decode()
            if data:
                print(f'Received {data} from {address}')
                broadcast(data,client_socket)

        except:
            break

    print('connection lost')
    clients.remove(client_socket)
    client_socket.close()

def broadcast(data,client_socket):
    for client in clients:
        try: 
            if client != client_socket:
                client.send(data.encode('utf-8'))

        except:
            clients.remove(client)
            client.close()

server_address = ('localhost',5005)
server_socket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)

server_socket.bind(server_address)
server_socket.listen()

while True:
    client_socket, address = server_socket.accept()
    thread = threading.Thread(target=handle_clients,args=(client_socket,address))
    thread.start()

    