import threading
import sys 
import socket 

lock = threading.Lock()

def receive_message(client_socket):
    print(f'{client_socket} is currently receiving messages...')

    while True:
        try: 
            message = client_socket.recv(1024).decode()
            if message:
                with lock:
                    sys.stdout.write("\r\033[K")
                    print(f'Message from server: {message}')
                    print('YOU: ',end='',flush=True)

        except:
            client_socket.close()
            break 


client_socket = socket.socket(socket.AF_INET6,socket.SOCK_STREAM)
client_socket.connect(('localhost',5006))

thread = threading.Thread(target=receive_message, args=(client_socket,))
thread.start()

while True:
    try:
        message = input('YOU: ')
        if message.lower() == 'quit':
            client_socket.send('Client is quitting'.encode('utf-8'))
            client_socket.close()
            break

        else:
            client_socket.send(message.encode('utf-8'))

    except:
        client_socket.close()
        break