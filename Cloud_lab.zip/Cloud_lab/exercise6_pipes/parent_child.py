max_size = 100 
import os

def ipc():
    p2c = os.pipe()
    c2p = os.pipe()

    pid = os.fork()

    if pid > 0:
        os.close(p2c[0])
        os.close(c2p[1])

        message = input('Parent, enter your message: ')
        os.write(p2c[1],message.encode())
        os.close(p2c[1])

        print("Parent reading reply from child...")
        reply = os.read(c2p[0],max_size).decode()
        print('Reply: ',reply)
        os.close(c2p[0])

    else:
        os.close(p2c[1])
        os.close(c2p[0])

        reply = os.read(p2c[0],max_size).decode()
        print('Message from parent: ',reply)
        os.close(p2c[0])

        message = input("Child, enter your message: ")
        os.write(c2p[1],message.encode())
        os.close(c2p[1])

if __name__ == '__main__':
    ipc()