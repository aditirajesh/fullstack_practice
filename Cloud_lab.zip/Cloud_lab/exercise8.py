from multiprocessing import shared_memory, Process, Queue 
import time 

def writer(sm_name,input_queue):
    existing_sm = shared_memory.SharedMemory(name=sm_name)

    while True:
        message = input_queue.get()
        existing_sm.buf[:len(message)] = message.encode()

        if message.lower() == 'quit':
            print('Writer is quitting...')
            break 

        print('Writer has written message into sm: ',message)
        time.sleep(1)


def reader(sm_name,size):
    existing_sm = shared_memory.SharedMemory(name=sm_name)

    while True:
        message = bytes(existing_sm.buf[:size]).decode().strip()
        if 'quit' in message:
            print('reader will now stop reading')
            break 

        if message:
            print('Message: ',message)

        time.sleep(5)

if __name__ == '__main__':
    queue = Queue()
    initial_message = ' '*100
    sm = shared_memory.SharedMemory(create=True,size=len(initial_message))

    writer_process = Process(target=writer, args=(sm.name,queue))
    writer_process.start()

    reader_process = Process(target=reader, args=(sm.name,len(initial_message)))
    reader_process.start()

    while True:
        message = input('Enter message: ')
        queue.put(message)

        if message == 'quit':
            break 

    writer_process.join()
    reader_process.join()

    sm.close()
    sm.unlink()

