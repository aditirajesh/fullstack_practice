import socket 

server_address = ('localhost',5007)
server_socket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)

server_socket.bind(server_address)
server_socket.listen()

client_socket, client_address = server_socket.accept()

with open("received_text","wb") as f:
    while True:
        data = client_socket.recv(1024)
        if not data:
            break 
        f.write(data)

print('File received and saved in as "received.txt"')
client_socket.close()
server_socket.close()