import socket

server_address = ('localhost',5007)
client_socket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)

client_socket.connect(server_address)

print('connected to server')

with open('sample.txt','rb') as f:
    data = f.read(1024)
    while data:
        client_socket.send(data)
        data = f.read(1024)

f.close()
print('file has been sent to the server')
client_socket.close()