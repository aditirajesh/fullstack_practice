import threading 
import sys 
import socket

lock = threading.Lock()

def receive_message(client_socket):
    print(f'{client_socket} has connected to the server')

    while True:
        try: 
            data = client_socket.recv(1024).decode()
            if data:
                with lock:
                    sys.stdout.write('\r\033[K')
                    print('message received: ',data)
                    print('YOU: ',end='',flush=True)

        except:
            client_socket.close()
            break


server_address = ('localhost',5005)
client_socket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
client_socket.connect(server_address)

thread = threading.Thread(target=receive_message,args=(client_socket,))
thread.start()

while True:
    message = input('Enter message: ')
    if message.lower() == 'quit':
        client_socket.send(f'{client_socket} is quitting the server'.encode('utf-8'))
        print('Quitting the server')
        client_socket.close()
        break 

    else:
         client_socket.send(message.encode())




