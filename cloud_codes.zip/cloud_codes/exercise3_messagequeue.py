from multiprocessing import Queue, Process 
import time 

def sender(queue):
    message1 = 'hello'
    message2 = 'i am aditi rajesh'

    queue.put(message1)
    queue.put(message2)

    print('message has been sent to queue')
    time.sleep(1)

def receiver(queue):
    time.sleep(2)
    while not queue.empty():
        message = queue.get()
        print(f'Received {message}')



if __name__ == "__main__":
    queue = Queue(5)

    sender_process = Process(target=sender,args=(queue,))
    receiver_process = Process(target=receiver, args=(queue,))

    sender_process.start()
    receiver_process.start()

    sender_process.join()
    receiver_process.join()

    print('message exchange complete')
